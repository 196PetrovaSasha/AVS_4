#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>
#include <unistd.h>
#include <fstream>
#include <cstring>
#include <vector>
#include <queue>


using namespace std;


struct customer_t {
    int index;
    int status;
};


int CHAIR_COUNT = 5;   //стулья в очереди


pthread_mutex_t mutex; // используется для реализации взаимного исключения процесса
sem_t barber;          // заставляет ждать клиента до окончания стрижки
bool barberSleep = false;


queue<customer_t> line = queue<customer_t>();


bool infl = false;//записываем ли результат в файл
ofstream MyFile("output.txt");

// процесс, отвечающий за действия клиента
void* customer_thread(void* params) {

    pthread_mutex_lock(&mutex);
    int custNumber = rand() % 1000 + 1;
    customer_t cust {
            custNumber, 0
    };
    cout << "[customer] I am new customer #" << custNumber << " | " << line.size() <<" people before me!\n";
    if (infl) {
        MyFile << "[customer] I am new customer #" << custNumber << " | " << line.size() <<" people before me!\n";
    }
    if (line.size() > CHAIR_COUNT) {
        //Мест нет
        cout << "[customer] No place for me in queue #"<< custNumber << "\n";
        if (infl) {
            MyFile << "[customer] No place for me in queue #"<< custNumber << "\n";
        }
        pthread_mutex_unlock(&mutex);
        return 0;
    }
    line.push(cust);
    pthread_mutex_unlock(&mutex);
    //Места есть, парикмахер делает стрижку
    sem_wait(&barber);
    cout << "[customer] Got the haircut #" << custNumber << "\n";
    if (infl) {
        MyFile << "[customer] Got the haircut #" << custNumber << "\n";
    }
    return 0;
}

// процесс, отвечающий за действия парикмахера
void* barber_thread(void* params) {

    while(true) {
        pthread_mutex_lock(&mutex);

        if (line.empty()) {
            //Никого нет, можно поспать
            pthread_mutex_unlock(&mutex);
            if (!barberSleep) {
                cout << "[barber] Barber sleep\n";
                if (infl) {
                    MyFile << "[barber] Barber sleep\n";
                }
                barberSleep = true;
            }

            sleep(5);
            continue;
        }
        //Барбер просыпается
        if (barberSleep) {
            barberSleep = false;
            cout << "[barber] Barber awake!\n";
            if (infl) {
                MyFile << "[barber] Barber awake!\n";
            }
        }
        //Берет первого человека в очереди
        customer_t cust = line.front();
        //Удаляем клиента из списка, ему место в очереди больше не нужно
        line.pop();
        pthread_mutex_unlock(&mutex);
        cout << "[barber] Processing customer #" << cust.index << "\n";
        if (infl) {
            MyFile << "[barber] Processing customer #" << cust.index << "\n";
        }
        sleep(rand() % 3 + 5);
        sem_post(&barber);
        sleep(5);
    }
    return 0;
}

int main() {
    //ввод параметра, количества стульев
    cout << "by default there are 5 chairs in the salon" << endl;
    cout << "if you want to change these parameters, press y,  if not, any other key " << endl;
    string par;
    cin >> par;
    if (par == "y") {
        cout << "select input format" << endl;
        cout << "1. Console" << endl;
        cout << "2. File" << endl;
        cout << "3. Random" << endl;
        string inpt;
        cin >> inpt;
        if (inpt == "1") {
            cout << "Enter queue size: ";
            cin >> CHAIR_COUNT;
        } else if (inpt == "2") {
            ifstream fin("input.txt");
            fin >> CHAIR_COUNT;
            fin.close();
            infl = true;
        } else if (inpt == "3") {
            CHAIR_COUNT = rand() % 10 + 3;
        } else {
            cout << "incorrect format, default settings remain\n";
        }
    }
    //начинается работа
    cout << "***************\n";
    cout << "Our store has " << CHAIR_COUNT << " chairs to wait\n";
    if (infl) {
        MyFile << "Our store has " << CHAIR_COUNT << " charis to wait\n";
    }

    //запускаем поток парикмахера
    pthread_t barber_thread_;
    pthread_mutex_init(&mutex, nullptr);
    sem_init(&barber, 0, 0);

    //вектор с клиентами
    vector<pthread_t> customers_thread = vector<pthread_t>();

    pthread_create(&barber_thread_, nullptr, barber_thread, nullptr);

    while (true) {
        // создаем новых клиентов
        sleep(rand() % 5 + 3);
        pthread_t new_customer;
        customers_thread.push_back(new_customer);
        pthread_create(&customers_thread.back(), nullptr, customer_thread, nullptr);
    }
    return 0;
}

